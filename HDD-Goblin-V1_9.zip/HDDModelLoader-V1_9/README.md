# HDDModelLoader — SwarmUI Extension

Speeds up model loading from a spinning hard disk by **sequentially buffering the
model file into RAM** before ComfyUI loads it.

```
HDD  ──sequential read──▶  RAM cache  ──fast read──▶  ComfyUI / GPU
```

HDDs are **10–100× slower at random I/O** than sequential I/O.  
PyTorch / safetensors loading does many random seeks. Buffering first lets the HDD
work at its peak throughput; ComfyUI then loads from RAM at memory speed.

Cost: **extra RAM equal to the model size** (e.g. a 10 GiB FLUX model needs 10 GiB
of headroom). If you have the RAM to spare, load times can drop from minutes to seconds.

---

## Setup

### Linux (recommended — RAM is automatic)

Nothing extra needed. The extension uses `/dev/shm` by default, which is a
`tmpfs` mount that **lives entirely in RAM** on every standard Linux distro.

### Windows

Windows has no built-in RAM disk. Install one of these free tools first:

| Tool | Download |
|------|----------|
| **ImDisk Toolkit** (recommended) | https://sourceforge.net/projects/imdisk-toolkit/ |
| OSFMount | https://www.osforensics.com/tools/mount-disk-images.html |

Create a RAM disk drive (e.g. `R:\`) large enough for your biggest model.

Then in SwarmUI → *Server → Server Configuration*, set **HDDModelLoader → Cache Path**
to something like `R:\ModelCache`.

---

## How it works

1. `OnPreInit` determines the cache root (`/dev/shm/swarm_model_cache` on Linux,
   or your configured path).
2. `OnInit` appends a block to ComfyUI's `extra_model_paths.yaml` so ComfyUI
   searches the cache directory by the same relative model names Swarm passes.
3. A `WorkflowGenerator.AddModelGenStep` hook fires at priority **−201** (just
   before the built-in model-loading steps at −200).  It calls `CopySequential`,
   which opens the source file with `FileOptions.SequentialScan` and a 64 MiB
   buffer to maximise HDD throughput.
4. ComfyUI receives the workflow normally. Because `extra_model_paths.yaml` lists
   the cache root, it finds and loads the RAM-backed copy instead of the HDD file.
5. A per-session dictionary prevents re-copying on subsequent generations with the
   same model.

### Eviction

Set **Max Cache MiB** in Server Configuration to cap RAM usage. The oldest cached
model is evicted (LRU) when the limit would be exceeded.

### Cleanup on shutdown

Enabled by default (**Cleanup On Shutdown = true**). Disable it if you want to keep
the cache warm across SwarmUI restarts (the machine must stay on).

---

## Installation

```bash
cd /path/to/SwarmUI/src/Extensions/
git clone https://github.com/YOUR_USERNAME/HDDModelLoader
# Then run the SwarmUI update script or launch with launch-dev:
./launch-linux-dev.sh      # Linux
# launch-windows-dev.ps1   # Windows
```

ComfyUI **must be restarted once** after the first run so it picks up the new
`extra_model_paths.yaml` entry.  Swarm will log a reminder.

---

## Configuration (Server → Server Configuration)

| Setting | Default | Description |
|---------|---------|-------------|
| `CachePath` | *(auto)* | Override the cache directory. Leave blank for auto-detect. |
| `CleanupOnShutdown` | `true` | Delete cache files when SwarmUI shuts down. |
| `MaxCacheMiB` | `0` | RAM cap in MiB. `0` = unlimited. |

---

## Limitations & notes

- Works with the **self-start ComfyUI backend**. For a remote ComfyUI, the cache
  path must be accessible from that machine and `extra_model_paths.yaml` must be
  updated there manually.
- The cache holds the full model file. A 12 GiB model needs 12 GiB of free RAM.
- LoRAs, VAE, ControlNet, CLIP, etc. are **not** automatically pre-cached (the
  hook only intercepts the primary checkpoint). Extend `OnInit` to add hooks for
  those param types if needed.
- If the cache directory fills up and `MaxCacheMiB` is 0, no eviction happens —
  the copy will fail and SwarmUI will fall back to loading from HDD normally.

---

## License

MIT

---

## Changelog

### V1.8 — Bug fixes

- **Fix (FREEZE):** `swarm_ram_cache.yaml` was never actually loaded by standard ComfyUI (which only reads `extra_model_paths.yaml`). The extension now **prepends** its block to `extra_model_paths.yaml` so ComfyUI discovers the RAM disk paths on startup. Prepending instead of appending gives the RAM disk priority over the original HDD paths.
- **Fix (FREEZE):** `SettingCachePath` defaulted to `R:\ModelCache` instead of `""`, disabling the extension on Linux and any Windows system without an `R:` drive.
- **Fix (FREEZE):** `RegisterCacheWithComfyUI()` now runs in **both** `OnPreInit` and `OnInit`. ComfyUI can start during the Init phase, so registering only in `OnInit` could be too late.
- **Fix (FREEZE):** ComfyUI path detection tried only one hardcoded path (`dlbackend/comfy/ComfyUI`) and logged at `Debug` level (invisible by default) when it was missing. Now tries four known layouts and logs a `Warning` with clear instructions if none are found.
- **Fix:** `KnownInVram` entries never expired. If ComfyUI evicted a model from VRAM (loading another large model), the extension assumed it was still there and skipped re-copying, causing a silent HDD load. Now cross-checked against `AnyBackendsHaveLoaded` on every access.
- **Fix:** Watcher `finally` block could remove the *replacement* watcher's CTS entry after a cancel, breaking future cancellation for that path. Now uses a reference equality check before removing.
- **Fix:** `DeleteAllCachedFiles` iterated `WatcherCts` in a `foreach` then called `.Clear()` while watcher tasks were concurrently calling `TryRemove` on the same dict. Now drains entry-by-entry with `TryRemove`.
- **Fix:** `Console.WriteLine("  Done")` fired unconditionally after both the success path (which already printed completion) and the timeout/cancel path. Now only printed on success as a confirmation that the RAM-disk copy was deleted.

### V1.9 — Bug fix

- **Fix:** ComfyUI crashed on startup with `FileNotFoundError` on `swarm_model_cache\checkpoints` (and all other subfolders). ComfyUI calls `os.path.getmtime()` on every registered model path at startup to build its file-list cache. The extension registered those paths in `extra_model_paths.yaml` but only created the root `swarm_model_cache` directory — not the subfolders — because nothing had been copied yet. ComfyUI sees a missing folder and throws. All eight subfolders (`checkpoints`, `diffusion_models`, `loras`, `vae`, `controlnet`, `clip`, `upscale_models`, `embeddings`) are now created on startup so ComfyUI can scan them even when empty.
