using SwarmUI.Core;
using SwarmUI.Utils;
using SwarmUI.Text2Image;
using SwarmUI.Builtin_ComfyUIBackend;
using System.Collections.Concurrent;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

// NOTE: Namespace must NOT contain "SwarmUI"
namespace HDDModelLoader;

/// <summary>
/// HDD Model Loader Extension for SwarmUI
///
/// Flow per generation:
///   1. Sequential copy: HDD → RAM disk  (progress bar in console)
///   2. ComfyUI loads the model from RAM disk  (fast, shown with spinner)
///   3. Background watcher detects load complete → deletes file, marks VRAM
///   4. Subsequent generations with the same model skip the copy entirely
///   5. If generation is cancelled (X button), watcher detects timeout / new
///      request, cleans up the RAM disk, and resets state for a clean retry.
///
/// Config: edit the SettingXxx fields below and relaunch SwarmUI.
/// </summary>
public class HDDModelLoader : Extension
{
    // ── Configuration ─────────────────────────────────────────────────────────
    //
    //  SettingCachePath
    //    ""              → auto-detect (/dev/shm on Linux, Temp on Windows)
    //    @"R:\ModelCache"  → RAM disk path (Windows example)
    //
    //  SettingCleanupOnShutdown
    //    true  → delete leftover cache files on SwarmUI exit
    //    false → leave them (useful if you restart SwarmUI but not the PC)
    //
    //  SettingMaxCacheMiB
    //    0  → no limit
    //    >0 → cap in MiB; oldest file evicted when exceeded
    //
    //  SettingLoadTimeoutSecs
    //    How long (seconds) to wait for ComfyUI to load the model before
    //    giving up, cleaning up the RAM disk copy, and resetting state.
    //    Default 300 (5 minutes) is generous; reduce if you want faster
    //    cleanup after a cancel.
    // ─────────────────────────────────────────────────────────────────────────

    // FIX #2: Was @"R:\ModelCache" — a hardcoded Windows-only path that disabled
    // the extension on Linux (invalid path → Directory.CreateDirectory throws →
    // CacheRoot = "" → extension disabled) and on Windows without an R: drive.
    // Now defaults to "" so the cross-platform auto-detect logic always runs.
    // Windows users with a RAM disk: set this to e.g. @"R:\ModelCache".
    public static string SettingCachePath        = "";
    public static bool   SettingCleanupOnShutdown = true;
    public static int    SettingMaxCacheMiB       = 0;
    public static int    SettingLoadTimeoutSecs   = 300;

    // ── Internal state ────────────────────────────────────────────────────────

    private static string CacheRoot = "";

    /// <summary>srcPath → destPath for files currently on the RAM disk.</summary>
    private static readonly ConcurrentDictionary<string, string> Cache = new();

    /// <summary>
    /// Paths confirmed loaded in VRAM this session.
    /// Cross-checked against AnyBackendsHaveLoaded on every access so that a
    /// VRAM eviction (ComfyUI swapping in a different model) triggers a re-copy.
    /// </summary>
    private static readonly ConcurrentDictionary<string, byte> KnownInVram = new();

    /// <summary>
    /// Per-srcPath CancellationTokenSource for the background watcher task.
    /// When a new generation for the same model starts while the old watcher
    /// is still running, we cancel the old watcher first.
    /// </summary>
    private static readonly ConcurrentDictionary<string, CancellationTokenSource> WatcherCts = new();

    private static readonly ConcurrentQueue<string>                      LruQueue  = new();
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> CopyLocks = new();
    private static long CachedBytes = 0;

    // ── Progress bar ──────────────────────────────────────────────────────────
    private const int BarWidth   = 40;
    private const int ReadBufMiB = 64;

    // Maps SwarmUI model handler type → ComfyUI subfolder in yaml
    private static readonly Dictionary<string, string> ModelTypeMap = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Stable-Diffusion"] = "checkpoints",
        ["LoRA"]             = "loras",
        ["VAE"]              = "vae",
        ["ControlNet"]       = "controlnet",
        ["Clip"]             = "clip",
        ["Embedding"]        = "embeddings",
        ["Upscale"]          = "upscale_models",
    };

    // ── Extension lifecycle ───────────────────────────────────────────────────

    public override void OnPreInit()
    {
        if (!string.IsNullOrWhiteSpace(SettingCachePath))
        {
            CacheRoot = SettingCachePath.Trim();
        }
        else if (OperatingSystem.IsLinux() && Directory.Exists("/dev/shm"))
        {
            CacheRoot = "/dev/shm/swarm_model_cache";
        }
        else
        {
            CacheRoot = Path.Combine(Path.GetTempPath(), "swarm_model_cache");
        }

        try
        {
            Directory.CreateDirectory(CacheRoot);

            // Pre-create every subfolder that will be registered in extra_model_paths.yaml.
            // ComfyUI calls os.path.getmtime() on each registered path at startup to build
            // its file-list cache. If a folder doesn't exist yet it throws FileNotFoundError
            // and the node fails to initialise — even though the folder is legitimately empty
            // at this point (no models have been copied yet). Creating the dirs up front
            // keeps ComfyUI happy regardless of whether anything has been cached.
            foreach (string sub in new[]
            {
                "checkpoints", "diffusion_models", "loras", "vae",
                "controlnet", "clip", "upscale_models", "embeddings",
            })
            {
                Directory.CreateDirectory(Path.Combine(CacheRoot, sub));
            }

            Logs.Init($"[HDDModelLoader] Cache root: {CacheRoot}");
        }
        catch (Exception ex)
        {
            Logs.Error($"[HDDModelLoader] Cannot create cache dir '{CacheRoot}': {ex.Message}");
            CacheRoot = "";
            return;
        }

        // FIX #3: Register YAML paths in OnPreInit as well as OnInit.
        // ComfyUI self-start can launch during the Init phase (same phase as OnInit),
        // so writing the YAML in OnInit alone risks being too late. Writing here in
        // OnPreInit guarantees the file exists before any backend process starts.
        // OnInit also writes it so changes made between phases are still applied.
        RegisterCacheWithComfyUI();
    }

    public override void OnInit()
    {
        if (string.IsNullOrEmpty(CacheRoot))
        {
            Logs.Warning("[HDDModelLoader] No cache root — extension disabled.");
            return;
        }

        // FIX #3 (continued): Write again in OnInit in case SwarmUI regenerated
        // extra_model_paths.yaml between PreInit and here (e.g. when backends
        // write their own sections during initialisation).
        RegisterCacheWithComfyUI();

        WorkflowGenerator.AddModelGenStep(g =>
        {
            if (!g.UserInput.TryGet(T2IParamTypes.Model, out T2IModel model) || model is null)
                return;
            EnsureModelCached(model);
        }, -201);

        AppDomain.CurrentDomain.ProcessExit += (_, _) =>
        {
            if (SettingCleanupOnShutdown)
                DeleteAllCachedFiles();
        };

        Logs.Init("[HDDModelLoader] Ready.");
    }

    // ── Core: copy + progress bar ─────────────────────────────────────────────

    private static void EnsureModelCached(T2IModel model)
    {
        string srcPath = model?.RawFilePath;
        if (string.IsNullOrEmpty(srcPath) || !File.Exists(srcPath))
            return;

        // FIX #5: KnownInVram entries no longer live forever.
        // If ComfyUI evicted this model from VRAM (e.g. it loaded a different
        // large model), AnyBackendsHaveLoaded will be false even though the path
        // is still in KnownInVram. Detect that and remove the stale entry so we
        // re-copy on the next generation instead of falling through to HDD load.
        if (KnownInVram.ContainsKey(srcPath))
        {
            if (model.AnyBackendsHaveLoaded)
            {
                Logs.Verbose($"[HDDModelLoader] '{model.Name}' already in VRAM — no copy needed.");
                return;
            }
            KnownInVram.TryRemove(srcPath, out _);
            Logs.Info($"[HDDModelLoader] '{model.Name}' was evicted from VRAM — will re-copy to RAM disk.");
        }

        // Belt-and-suspenders: also honour SwarmUI's own flag.
        if (model.AnyBackendsHaveLoaded)
            return;

        // File already on RAM disk (e.g. previous gen was cancelled mid-load).
        // Cancel the stale watcher and start a fresh one for the new attempt.
        if (Cache.TryGetValue(srcPath, out string existingDest) && File.Exists(existingDest))
        {
            Console.WriteLine("\n  [HDDModelLoader] Model already on RAM disk — resuming load watch.");
            ScheduleWatcher(model, srcPath, existingDest);
            return;
        }

        SemaphoreSlim sem = CopyLocks.GetOrAdd(srcPath, _ => new SemaphoreSlim(1, 1));
        sem.Wait();
        try
        {
            // Double-check inside lock.
            if (KnownInVram.ContainsKey(srcPath) || model.AnyBackendsHaveLoaded)
                return;

            if (Cache.TryGetValue(srcPath, out existingDest) && File.Exists(existingDest))
            {
                ScheduleWatcher(model, srcPath, existingDest);
                return;
            }

            string destPath = BuildCacheDest(model);
            if (string.IsNullOrEmpty(destPath))
                return;

            long fileBytes = new FileInfo(srcPath).Length;
            if (SettingMaxCacheMiB > 0)
                EvictIfNeeded(fileBytes);

            Console.WriteLine();
            CopyWithProgress(srcPath, destPath, fileBytes);

            Cache[srcPath] = destPath;
            LruQueue.Enqueue(srcPath);
            Interlocked.Add(ref CachedBytes, fileBytes);

            ScheduleWatcher(model, srcPath, destPath);
        }
        catch (Exception ex)
        {
            Logs.Error($"[HDDModelLoader] Copy failed: {ex.Message}");
            Console.WriteLine($"\n  [HDDModelLoader] ERROR during copy: {ex.Message}");
        }
        finally
        {
            sem.Release();
        }
    }

    private static void CopyWithProgress(string src, string dest, long totalBytes)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(dest)!);

        int    bufSize   = ReadBufMiB * 1024 * 1024;
        byte[] buf       = new byte[bufSize];
        long   copied    = 0;
        long   prevBytes = 0;
        var    sw        = Stopwatch.StartNew();
        var    prevTime  = sw.Elapsed;

        using var reader = new FileStream(src,  FileMode.Open,   FileAccess.Read,  FileShare.Read,
                                          bufSize, FileOptions.SequentialScan);
        using var writer = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None,
                                          bufSize);
        int read;
        while ((read = reader.Read(buf, 0, buf.Length)) > 0)
        {
            writer.Write(buf, 0, read);
            copied += read;

            var    now      = sw.Elapsed;
            double chunkSec = (now - prevTime).TotalSeconds;
            double mbps     = chunkSec > 0.05
                ? (copied - prevBytes) / (1024.0 * 1024.0) / chunkSec
                : 0;
            prevBytes = copied;
            prevTime  = now;

            double pct    = totalBytes > 0 ? (double)copied / totalBytes : 0;
            int    filled = (int)(pct * BarWidth);
            string bar    = new string('\u2588', filled) + new string('-', BarWidth - filled);
            long   mibDone  = copied    / (1024 * 1024);
            long   mibTotal = totalBytes / (1024 * 1024);

            Console.Write(
                $"\r  Loading model from HDD: [{bar}] {pct * 100,3:F0}%" +
                $" | {mbps,5:F0} MB/s  ({mibDone}/{mibTotal} MiB)   ");
        }

        double avgMbps = sw.Elapsed.TotalSeconds > 0
            ? (totalBytes / (1024.0 * 1024.0)) / sw.Elapsed.TotalSeconds : 0;
        long mib = totalBytes / (1024 * 1024);
        Console.WriteLine(
            $"\r  Loading model from HDD: [{new string('\u2588', BarWidth)}] 100%" +
            $" | avg {avgMbps,5:F0} MB/s  ({mib}/{mib} MiB)   ");
    }

    // ── Watcher: spinner, cancellation, cleanup ───────────────────────────────

    /// <summary>
    /// Starts (or restarts) a background watcher for the given model.
    ///
    /// If a previous watcher for the same srcPath is still running (left over
    /// from a cancelled generation), it is cancelled first. This ensures only
    /// one watcher per file is ever active, and a retry after pressing X gets
    /// a clean start.
    /// </summary>
    private static void ScheduleWatcher(T2IModel model, string srcPath, string destPath)
    {
        // Cancel and replace any existing watcher for this path.
        if (WatcherCts.TryRemove(srcPath, out CancellationTokenSource oldCts))
        {
            oldCts.Cancel();
            oldCts.Dispose();
        }

        var cts = new CancellationTokenSource();
        WatcherCts[srcPath] = cts;

        _ = Task.Run(async () =>
        {
            char[] spinChars = ['|', '/', '-', '\\'];
            int    polls     = 0;
            int    timeout   = Math.Max(30, SettingLoadTimeoutSecs);
            var    loadSw    = Stopwatch.StartNew();
            bool   wasLoaded = false;

            try
            {
                while (!model.AnyBackendsHaveLoaded && polls < timeout)
                {
                    try
                    {
                        await Task.Delay(1000, cts.Token);
                    }
                    catch (OperationCanceledException)
                    {
                        // A newer watcher for this path took over — exit silently.
                        // The RAM disk file is intentionally left in place so the
                        // replacement watcher (already running) can use it without
                        // re-copying. Cache entry is also preserved for the same reason.
                        return;
                    }

                    polls++;
                    char spin = spinChars[polls % spinChars.Length];
                    Console.Write(
                        $"\r  Loading model from RAM-disk ... [{spin}]  {loadSw.Elapsed.TotalSeconds:F0}s  ");
                }

                wasLoaded = model.AnyBackendsHaveLoaded;

                if (wasLoaded)
                {
                    // Success path.
                    Console.WriteLine(
                        $"\r  Loading model from RAM-disk ... Done  " +
                        $"({loadSw.Elapsed.TotalSeconds:F0}s elapsed)          ");
                    Console.WriteLine("  Deleting RAM-disk copy ...");

                    // Remember this model is now in VRAM for future generations.
                    KnownInVram[srcPath] = 1;
                }
                else
                {
                    // Timeout path — user cancelled, backend error, etc.
                    Console.WriteLine(
                        $"\r  Load cancelled / timed out after {loadSw.Elapsed.TotalSeconds:F0}s — " +
                        $"cleaning up RAM disk ...                    ");

                    // Remove from KnownInVram (should not be there, but be safe).
                    KnownInVram.TryRemove(srcPath, out _);
                }

                // Delete the RAM disk copy in both cases.
                if (File.Exists(destPath))
                {
                    try
                    {
                        long size = new FileInfo(destPath).Length;
                        File.Delete(destPath);
                        Interlocked.Add(ref CachedBytes, -size);
                        Logs.Info($"[HDDModelLoader] Freed {size / (1024 * 1024)} MiB from RAM disk.");
                    }
                    catch (Exception ex)
                    {
                        Logs.Warning($"[HDDModelLoader] Could not delete cache file: {ex.Message}");
                    }
                }

                Cache.TryRemove(srcPath, out _);
                TryCleanEmptyDirs(Path.GetDirectoryName(destPath));

                // FIX #8: Was an unconditional Console.WriteLine("  Done") which fired
                // after both the success message AND the timeout/cancel message, making
                // output confusing in both cases. Now only printed on the success path
                // as a clean confirmation that the RAM-disk copy was deleted.
                if (wasLoaded)
                    Console.WriteLine("  RAM-disk copy deleted.");
            }
            catch (Exception ex)
            {
                Logs.Warning($"[HDDModelLoader] Watcher error: {ex.Message}");
            }
            finally
            {
                // FIX #6: Was WatcherCts.TryRemove(srcPath, out _) unconditionally.
                // Race condition: if a new watcher for the same srcPath was started
                // (via ScheduleWatcher cancelling us), WatcherCts[srcPath] now holds
                // the NEW watcher's CTS. Blindly removing it would unregister the live
                // watcher, breaking future cancellation for that path. Only remove if
                // the entry still points to OUR OWN CTS.
                if (WatcherCts.TryGetValue(srcPath, out var currentCts)
                    && ReferenceEquals(currentCts, cts))
                {
                    WatcherCts.TryRemove(srcPath, out _);
                }
                cts.Dispose();
            }
        });
    }

    private static void TryCleanEmptyDirs(string dir)
    {
        if (string.IsNullOrEmpty(dir)) return;
        try
        {
            while (!string.Equals(dir, CacheRoot, StringComparison.OrdinalIgnoreCase)
                   && Directory.Exists(dir)
                   && Directory.GetFileSystemEntries(dir).Length == 0)
            {
                Directory.Delete(dir);
                dir = Path.GetDirectoryName(dir);
            }
        }
        catch { /* best-effort */ }
    }

    // ── Path helpers ──────────────────────────────────────────────────────────

    private static string BuildCacheDest(T2IModel model)
    {
        string sub  = GetComfySubfolder(model);
        string name = model.Name.Replace('\\', '/');
        return Path.Combine(CacheRoot, sub, name.Replace('/', Path.DirectorySeparatorChar));
    }

    private static string GetComfySubfolder(T2IModel model)
    {
        string modelType = model.Handler?.ModelType ?? "";
        if (ModelTypeMap.TryGetValue(modelType, out string sub))
            return sub;

        string orig = (model.OriginatingFolderPath ?? "")
                      .Replace('\\', '/').TrimEnd('/').ToLowerInvariant();
        if (orig.EndsWith("/diffusion_models") || orig.EndsWith("/unet")) return "diffusion_models";
        if (orig.EndsWith("/loras") || orig.EndsWith("/lora"))             return "loras";
        if (orig.EndsWith("/vae"))                                         return "vae";
        if (orig.EndsWith("/controlnet"))                                  return "controlnet";
        if (orig.EndsWith("/clip"))                                        return "clip";
        if (orig.EndsWith("/upscale_models"))                              return "upscale_models";
        if (orig.EndsWith("/embeddings"))                                   return "embeddings";

        return "checkpoints";
    }

    // ── Eviction ──────────────────────────────────────────────────────────────

    private static void EvictIfNeeded(long neededBytes)
    {
        long limit = (long)SettingMaxCacheMiB * 1024 * 1024;
        if (limit <= 0) return;
        while (Interlocked.Read(ref CachedBytes) + neededBytes > limit
               && LruQueue.TryDequeue(out string oldSrc))
        {
            if (Cache.TryRemove(oldSrc, out string oldDest))
            {
                try
                {
                    long size = File.Exists(oldDest) ? new FileInfo(oldDest).Length : 0;
                    File.Delete(oldDest);
                    Interlocked.Add(ref CachedBytes, -size);
                }
                catch { /* best-effort */ }
            }
        }
    }

    private static void DeleteAllCachedFiles()
    {
        // FIX #7: Was iterating WatcherCts in a foreach and then calling .Clear().
        // Watcher tasks also call TryRemove on WatcherCts in their finally blocks,
        // creating a race. Drain the dict entry-by-entry with TryRemove instead,
        // which is safe for concurrent access on ConcurrentDictionary.
        foreach (string key in WatcherCts.Keys.ToArray())
        {
            if (WatcherCts.TryRemove(key, out CancellationTokenSource cts))
            {
                try { cts.Cancel(); cts.Dispose(); } catch { }
            }
        }

        foreach (var (_, dest) in Cache)
            try { File.Delete(dest); } catch { }
        Cache.Clear();
        KnownInVram.Clear();
        if (Directory.Exists(CacheRoot))
            try { Directory.Delete(CacheRoot, recursive: true); } catch { }
        Interlocked.Exchange(ref CachedBytes, 0);
    }

    // ── ComfyUI yaml registration ─────────────────────────────────────────────

    /// <summary>
    /// Registers our RAM cache as a model search path so ComfyUI finds
    /// the cached copy instead of loading from HDD.
    ///
    /// Dual-write strategy (both writes are required for full compatibility):
    ///
    ///   1. Prepends a 'swarm_ram_cache:' block to extra_model_paths.yaml.
    ///      Standard ComfyUI only reads this file (unless given
    ///      --extra-model-paths-config). Prepending instead of appending
    ///      gives our RAM-disk paths higher priority than the HDD originals.
    ///
    ///   2. Also writes swarm_ram_cache.yaml for ComfyUI builds that do scan
    ///      all *.yaml files in their root directory.
    ///
    /// Called from both OnPreInit and OnInit so the file is current regardless
    /// of whether ComfyUI starts early (during Init) or late.
    /// </summary>
    private static void RegisterCacheWithComfyUI()
    {
        // FIX #4: Was a single hardcoded path "dlbackend/comfy/ComfyUI".
        // SwarmUI's ComfyUI install location varies by version and setup.
        // Try all known layouts; use the first that contains main.py.
        string basePath = Path.GetFullPath(Environment.CurrentDirectory);
        string comfyRoot = FindComfyRoot(basePath);

        if (string.IsNullOrEmpty(comfyRoot))
        {
            // FIX #4 (continued): Was Logs.Debug — invisible at default log level,
            // so users had no idea why models were loading from HDD. Now a Warning.
            Logs.Warning(
                "[HDDModelLoader] Could not locate ComfyUI directory. " +
                "Tried: dlbackend/comfy/ComfyUI, dlbackend/ComfyUI, dlbackend/comfy, ComfyUI. " +
                "ComfyUI will NOT know about the RAM disk cache and will load models from HDD. " +
                "If you use a custom ComfyUI path, add the swarm_ram_cache block to your " +
                "extra_model_paths.yaml manually (see README).");
            return;
        }

        string wantedBase = CacheRoot.Replace('\\', '/');
        string yamlBlock  = BuildYamlBlock(wantedBase);

        // ── Write 1: extra_model_paths.yaml (standard ComfyUI) ───────────────
        //
        // FIX #1: The original code only wrote swarm_ram_cache.yaml, relying on
        // the incorrect assumption that ComfyUI scans all *.yaml files in its
        // root. Standard ComfyUI only reads extra_model_paths.yaml. Without this
        // write, ComfyUI never discovers the RAM disk paths and the spinner after
        // "Loading model from HDD" stalls indefinitely while ComfyUI re-reads
        // the original HDD file.
        //
        // We PREPEND our block so RAM-disk paths are found before the originals.
        string extraYaml = Path.Combine(comfyRoot, "extra_model_paths.yaml");
        try
        {
            string existing = File.Exists(extraYaml) ? File.ReadAllText(extraYaml) : "";

            if (!existing.Contains("swarm_ram_cache:"))
            {
                // First time: prepend our block.
                File.WriteAllText(extraYaml, yamlBlock + "\n" + existing);
                Logs.Info($"[HDDModelLoader] Prepended swarm_ram_cache to extra_model_paths.yaml → {wantedBase}");
                Logs.Info("[HDDModelLoader] *** Restart ComfyUI once (relaunch SwarmUI) for the new paths to take effect. ***");
            }
            else if (!existing.Contains($"base_path: {wantedBase}"))
            {
                // Cache path changed — replace the stale block.
                string updated = ReplaceYamlBlock(existing, yamlBlock);
                File.WriteAllText(extraYaml, updated);
                Logs.Info($"[HDDModelLoader] Updated swarm_ram_cache in extra_model_paths.yaml → {wantedBase}");
                Logs.Info("[HDDModelLoader] *** Restart ComfyUI once (relaunch SwarmUI) for the updated paths to take effect. ***");
            }
            else
            {
                Logs.Debug("[HDDModelLoader] extra_model_paths.yaml already up to date.");
            }
        }
        catch (Exception ex)
        {
            Logs.Warning($"[HDDModelLoader] Could not update extra_model_paths.yaml: {ex.Message}");
        }

        // ── Write 2: swarm_ram_cache.yaml (ComfyUI builds that scan *.yaml) ──
        string ramYaml = Path.Combine(comfyRoot, "swarm_ram_cache.yaml");
        try
        {
            if (!File.Exists(ramYaml) ||
                !File.ReadAllText(ramYaml).Contains($"base_path: {wantedBase}"))
            {
                File.WriteAllText(ramYaml,
                    "# Auto-generated by HDDModelLoader SwarmUI extension.\n" +
                    "# Safe to delete — it will be recreated on next launch.\n" +
                    yamlBlock);
                Logs.Debug($"[HDDModelLoader] Wrote swarm_ram_cache.yaml → {wantedBase}");
            }
        }
        catch (Exception ex)
        {
            Logs.Warning($"[HDDModelLoader] Could not write swarm_ram_cache.yaml: {ex.Message}");
        }
    }

    private static string BuildYamlBlock(string basePath) =>
        "swarm_ram_cache:\n" +
        $"  base_path: {basePath}\n" +
        "  checkpoints: checkpoints\n" +
        "  diffusion_models: diffusion_models\n" +
        "  unet: diffusion_models\n" +
        "  loras: loras\n" +
        "  vae: vae\n" +
        "  controlnet: controlnet\n" +
        "  clip: clip\n" +
        "  upscale_models: upscale_models\n" +
        "  embeddings: embeddings\n";

    /// <summary>
    /// Replaces the existing swarm_ram_cache block in a YAML string with a new one.
    /// Finds the block by its header line and removes everything until the next
    /// top-level key (or end of file), then prepends the new block.
    /// </summary>
    private static string ReplaceYamlBlock(string yaml, string newBlock)
    {
        int start = yaml.IndexOf("swarm_ram_cache:", StringComparison.Ordinal);
        if (start < 0)
            return newBlock + "\n" + yaml;

        // Find the next top-level YAML key after our block.
        int search = yaml.IndexOf('\n', start);
        int end    = -1;
        while (search >= 0 && search < yaml.Length - 1)
        {
            search++;
            char c = yaml[search];
            if (c != ' ' && c != '\t' && c != '#' && c != '\n' && c != '\r')
            {
                end = search;
                break;
            }
            search = yaml.IndexOf('\n', search);
        }

        string rest = end >= 0 ? yaml[end..] : "";
        string before = start > 0 ? yaml[..start].TrimEnd() + "\n\n" : "";
        return newBlock + "\n" + before + rest;
    }

    /// <summary>
    /// Searches known ComfyUI install locations and returns the first directory
    /// that looks like a ComfyUI root (contains main.py).
    /// Falls back to the first existing directory if none have main.py.
    /// </summary>
    private static string FindComfyRoot(string basePath)
    {
        // FIX #4: Try all known layouts rather than one hardcoded path.
        string[] candidates =
        [
            Path.Combine(basePath, "dlbackend", "comfy", "ComfyUI"),  // default self-start
            Path.Combine(basePath, "dlbackend", "ComfyUI"),           // alternate layout
            Path.Combine(basePath, "dlbackend", "comfy"),             // flat comfy dir
            Path.Combine(basePath, "ComfyUI"),                        // side-by-side install
        ];

        // Prefer a directory that actually has main.py (confirms it's ComfyUI).
        foreach (string c in candidates)
            if (Directory.Exists(c) && File.Exists(Path.Combine(c, "main.py")))
                return c;

        // Fallback: first directory that exists (some ComfyUI variants may differ).
        foreach (string c in candidates)
            if (Directory.Exists(c))
                return c;

        return "";
    }
}
