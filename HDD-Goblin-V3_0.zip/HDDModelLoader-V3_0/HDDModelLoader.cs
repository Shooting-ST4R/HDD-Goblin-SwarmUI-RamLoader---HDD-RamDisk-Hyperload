using SwarmUI.Core;
using SwarmUI.Utils;
using SwarmUI.Text2Image;
using SwarmUI.Builtin_ComfyUIBackend;
using System.Collections.Concurrent;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

// NOTE: Namespace must NOT contain "SwarmUI"
namespace HDDModelLoader;

/// <summary>
/// HDD Model Loader Extension for SwarmUI
///
/// Flow per generation:
///   1. Sequential copy: HDD → RAM disk  (progress bar in console)
///   2. RAM disk path is registered as a ComfyUI search path via extra_model_paths.yaml
///      (prepended so it is found before the HDD path)
///   3. ComfyUI loads the model from RAM disk (fast, shown with spinner)
///   4. Background watcher detects load complete → deletes RAM disk copy
///   5. If generation is cancelled, watcher detects cancellation, cleans up RAM disk
///
/// Every generation is treated as a fresh start — no cross-generation state is
/// carried over, so re-loads behave identically to the very first load.
///
/// Config: edit the SettingXxx fields below and relaunch SwarmUI.
/// </summary>
public class HDDModelLoader : Extension
{
    // ── Configuration ─────────────────────────────────────────────────────────
    public static string SettingCachePath         = "";
    public static bool   SettingCleanupOnShutdown = true;
    public static int    SettingMaxCacheMiB        = 0;
    public static int    SettingLoadTimeoutSecs    = 300;

    // ── Internal state ────────────────────────────────────────────────────────

    private static string CacheRoot = "";

    /// <summary>srcPath → destPath for files currently on the RAM disk.</summary>
    private static readonly ConcurrentDictionary<string, string> Cache = new();

    /// <summary>Per-srcPath CTS for background watcher tasks.</summary>
    private static readonly ConcurrentDictionary<string, CancellationTokenSource> WatcherCts = new();

    private static readonly ConcurrentQueue<string>                      LruQueue  = new();
    private static readonly ConcurrentDictionary<string, SemaphoreSlim> CopyLocks = new();
    private static long CachedBytes = 0;

    private const int BarWidth   = 40;
    private const int ReadBufMiB = 64;

    private static readonly Dictionary<string, string> ModelTypeMap = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Stable-Diffusion"] = "checkpoints",
        ["LoRA"]             = "loras",
        ["VAE"]              = "vae",
        ["ControlNet"]       = "controlnet",
        ["Clip"]             = "clip",
        ["Embedding"]        = "embeddings",
        ["Upscale"]          = "upscale_models",
    };

    // ── Extension lifecycle ───────────────────────────────────────────────────

    public override void OnPreInit()
    {
        if (!string.IsNullOrWhiteSpace(SettingCachePath))
        {
            CacheRoot = SettingCachePath.Trim();
        }
        else if (OperatingSystem.IsLinux() && Directory.Exists("/dev/shm"))
        {
            CacheRoot = "/dev/shm/swarm_model_cache";
        }
        else if (OperatingSystem.IsWindows())
        {
            string[] candidates = [ @"R:\ModelCache", @"Z:\ModelCache", @"Q:\ModelCache" ];
            CacheRoot = candidates.FirstOrDefault(p => Directory.Exists(Path.GetPathRoot(p)))
                        ?? Path.Combine(Path.GetTempPath(), "swarm_model_cache");
        }
        else
        {
            CacheRoot = Path.Combine(Path.GetTempPath(), "swarm_model_cache");
        }

        try
        {
            Directory.CreateDirectory(CacheRoot);

            foreach (string sub in new[]
            {
                "checkpoints", "diffusion_models", "loras", "vae",
                "controlnet", "clip", "upscale_models", "embeddings",
            })
            {
                Directory.CreateDirectory(Path.Combine(CacheRoot, sub));
            }

            Logs.Init($"[HDDModelLoader] Cache root: {CacheRoot}");
        }
        catch (Exception ex)
        {
            Logs.Error($"[HDDModelLoader] Cannot create cache dir '{CacheRoot}': {ex.Message}");
            CacheRoot = "";
            return;
        }

        RegisterCacheWithComfyUI();
    }

    public override void OnInit()
    {
        if (string.IsNullOrEmpty(CacheRoot))
        {
            Logs.Warning("[HDDModelLoader] No cache root — extension disabled.");
            return;
        }

        RegisterCacheWithComfyUI();

        WorkflowGenerator.AddModelGenStep(g =>
        {
            if (!g.UserInput.TryGet(T2IParamTypes.Model, out T2IModel model) || model is null)
                return;
            EnsureModelCached(model);
        }, -201);

        AppDomain.CurrentDomain.ProcessExit += (_, _) =>
        {
            if (SettingCleanupOnShutdown)
                DeleteAllCachedFiles();
        };

        Logs.Init("[HDDModelLoader] Ready.");
    }

    // ── Core: copy ────────────────────────────────────────────────────────────

    private static void EnsureModelCached(T2IModel model)
    {
        string srcPath = model?.RawFilePath;
        if (string.IsNullOrEmpty(srcPath) || !File.Exists(srcPath))
            return;

        // Model already in VRAM — ComfyUI will reuse it without touching disk.
        if (model.AnyBackendsHaveLoaded)
        {
            Logs.Verbose($"[HDDModelLoader] '{model.Name}' already in VRAM — no copy needed.");
            return;
        }

        // File already on RAM disk (e.g. a previous generation was cancelled mid-load).
        if (Cache.TryGetValue(srcPath, out string existingDest) && File.Exists(existingDest))
        {
            Console.WriteLine("\n  [HDDModelLoader] Model already on RAM disk — resuming load watch.");
            ScheduleWatcher(model, srcPath, existingDest);
            return;
        }

        SemaphoreSlim sem = CopyLocks.GetOrAdd(srcPath, _ => new SemaphoreSlim(1, 1));
        sem.Wait();
        try
        {
            // Re-check inside lock in case another thread raced us.
            if (model.AnyBackendsHaveLoaded)
                return;

            if (Cache.TryGetValue(srcPath, out existingDest) && File.Exists(existingDest))
            {
                ScheduleWatcher(model, srcPath, existingDest);
                return;
            }

            string destPath = BuildCacheDest(model);
            if (string.IsNullOrEmpty(destPath))
                return;

            long fileBytes = new FileInfo(srcPath).Length;
            if (SettingMaxCacheMiB > 0)
                EvictIfNeeded(fileBytes);

            Console.WriteLine();
            CopyWithProgress(srcPath, destPath, fileBytes);

            Cache[srcPath] = destPath;
            LruQueue.Enqueue(srcPath);
            Interlocked.Add(ref CachedBytes, fileBytes);

            ScheduleWatcher(model, srcPath, destPath);
        }
        catch (Exception ex)
        {
            Logs.Error($"[HDDModelLoader] Copy failed: {ex.Message}");
            Console.WriteLine($"\n  [HDDModelLoader] ERROR during copy: {ex.Message}");
        }
        finally
        {
            sem.Release();
        }
    }

    // ── Watcher: spinner, cancellation, cleanup ───────────────────────────────

    private static void ScheduleWatcher(T2IModel model, string srcPath, string destPath)
    {
        if (WatcherCts.TryRemove(srcPath, out CancellationTokenSource oldCts))
        {
            oldCts.Cancel();
            oldCts.Dispose();
        }

        var cts = new CancellationTokenSource();
        WatcherCts[srcPath] = cts;

        _ = Task.Run(async () =>
        {
            char[] spinChars = ['|', '/', '-', '\\'];
            int    polls     = 0;
            int    timeout   = Math.Max(30, SettingLoadTimeoutSecs);
            var    loadSw    = Stopwatch.StartNew();
            bool   wasLoaded = false;

            try
            {
                // ── Phase 1: wait for NOT-loaded (clear any stale signal) ──────
                // If AnyBackendsHaveLoaded is already true when the watcher starts
                // (e.g. the model was still in VRAM from a previous generation), we
                // wait up to 10 s for it to drop to false before entering the load
                // poll.  This prevents a stale "already loaded" signal from
                // triggering premature cleanup before ComfyUI has opened the file.
                int clearPolls = 0;
                while (model.AnyBackendsHaveLoaded && clearPolls < 10)
                {
                    try { await Task.Delay(1000, cts.Token); }
                    catch (OperationCanceledException) { return; }
                    clearPolls++;
                }

                // ── Phase 2: wait for loaded (false → true transition) ─────────
                while (!model.AnyBackendsHaveLoaded && polls < timeout)
                {
                    try
                    {
                        await Task.Delay(1000, cts.Token);
                    }
                    catch (OperationCanceledException)
                    {
                        // A newer watcher took over — leave RAM disk copy in place
                        // for the replacement watcher to use.
                        return;
                    }

                    polls++;
                    char spin = spinChars[polls % spinChars.Length];
                    Console.Write(
                        $"\r  Loading model from RAM-disk ... [{spin}]  {loadSw.Elapsed.TotalSeconds:F0}s  ");
                }

                wasLoaded = model.AnyBackendsHaveLoaded;

                if (wasLoaded)
                {
                    Console.WriteLine(
                        $"\r  Loading model from RAM-disk ... Done  " +
                        $"({loadSw.Elapsed.TotalSeconds:F0}s elapsed)          ");
                    Console.WriteLine("  Cleaning up ...");
                }
                else
                {
                    Console.WriteLine(
                        $"\r  Load cancelled / timed out after {loadSw.Elapsed.TotalSeconds:F0}s — " +
                        $"cleaning up ...                    ");
                }

                if (File.Exists(destPath))
                {
                    try
                    {
                        long size = new FileInfo(destPath).Length;
                        File.Delete(destPath);
                        Interlocked.Add(ref CachedBytes, -size);
                        Logs.Info($"[HDDModelLoader] Freed {size / (1024 * 1024)} MiB from RAM disk.");
                    }
                    catch (Exception ex)
                    {
                        Logs.Warning($"[HDDModelLoader] Could not delete cache file: {ex.Message}");
                    }
                }

                Cache.TryRemove(srcPath, out _);
                TryCleanEmptyDirs(Path.GetDirectoryName(destPath));

                if (wasLoaded)
                    Console.WriteLine("  RAM-disk copy deleted.");
            }
            catch (Exception ex)
            {
                Logs.Warning($"[HDDModelLoader] Watcher error: {ex.Message}");
            }
            finally
            {
                if (WatcherCts.TryGetValue(srcPath, out var currentCts)
                    && ReferenceEquals(currentCts, cts))
                {
                    WatcherCts.TryRemove(srcPath, out _);
                }
                cts.Dispose();
            }
        });
    }

    private static void TryCleanEmptyDirs(string dir)
    {
        if (string.IsNullOrEmpty(dir)) return;
        try
        {
            while (!string.Equals(dir, CacheRoot, StringComparison.OrdinalIgnoreCase)
                   && Directory.Exists(dir)
                   && Directory.GetFileSystemEntries(dir).Length == 0)
            {
                Directory.Delete(dir);
                dir = Path.GetDirectoryName(dir);
            }
        }
        catch { /* best-effort */ }
    }

    // ── Path helpers ──────────────────────────────────────────────────────────

    private static string BuildCacheDest(T2IModel model)
    {
        string sub  = GetComfySubfolder(model);
        string name = model.Name.Replace('\\', '/');
        return Path.Combine(CacheRoot, sub, name.Replace('/', Path.DirectorySeparatorChar));
    }

    private static string GetComfySubfolder(T2IModel model)
    {
        string modelType = model.Handler?.ModelType ?? "";
        if (ModelTypeMap.TryGetValue(modelType, out string sub))
            return sub;

        string orig = (model.OriginatingFolderPath ?? "")
                      .Replace('\\', '/').TrimEnd('/').ToLowerInvariant();
        if (orig.EndsWith("/diffusion_models") || orig.EndsWith("/unet")) return "diffusion_models";
        if (orig.EndsWith("/loras") || orig.EndsWith("/lora"))             return "loras";
        if (orig.EndsWith("/vae"))                                         return "vae";
        if (orig.EndsWith("/controlnet"))                                  return "controlnet";
        if (orig.EndsWith("/clip"))                                        return "clip";
        if (orig.EndsWith("/upscale_models"))                              return "upscale_models";
        if (orig.EndsWith("/embeddings"))                                   return "embeddings";

        return "checkpoints";
    }

    // ── Eviction ──────────────────────────────────────────────────────────────

    private static void EvictIfNeeded(long neededBytes)
    {
        long limit = (long)SettingMaxCacheMiB * 1024 * 1024;
        if (limit <= 0) return;
        while (Interlocked.Read(ref CachedBytes) + neededBytes > limit
               && LruQueue.TryDequeue(out string oldSrc))
        {
            if (Cache.TryRemove(oldSrc, out string oldDest))
            {
                try
                {
                    long size = File.Exists(oldDest) ? new FileInfo(oldDest).Length : 0;
                    File.Delete(oldDest);
                    Interlocked.Add(ref CachedBytes, -size);
                }
                catch { /* best-effort */ }
            }
        }
    }

    private static void DeleteAllCachedFiles()
    {
        foreach (string key in WatcherCts.Keys.ToArray())
        {
            if (WatcherCts.TryRemove(key, out CancellationTokenSource cts))
            {
                try { cts.Cancel(); cts.Dispose(); } catch { }
            }
        }

        foreach (var (_, dest) in Cache)
            try { File.Delete(dest); } catch { }
        Cache.Clear();
        if (Directory.Exists(CacheRoot))
            try { Directory.Delete(CacheRoot, recursive: true); } catch { }
        Interlocked.Exchange(ref CachedBytes, 0);
    }

    // ── ComfyUI yaml registration ─────────────────────────────────────────────

    /// <summary>
    /// Registers the RAM disk cache as a ComfyUI model search path by prepending
    /// a swarm_ram_cache block to extra_model_paths.yaml.  ComfyUI scans search
    /// paths in order, so the RAM disk entry is checked before the HDD path.
    /// </summary>
    private static void RegisterCacheWithComfyUI()
    {
        string basePath  = Path.GetFullPath(Environment.CurrentDirectory);
        string comfyRoot = FindComfyRoot(basePath);

        if (string.IsNullOrEmpty(comfyRoot))
        {
            Logs.Warning(
                "[HDDModelLoader] Could not locate ComfyUI directory. " +
                "Tried: dlbackend/comfy/ComfyUI, dlbackend/ComfyUI, dlbackend/comfy, ComfyUI. " +
                "ComfyUI will NOT know about the RAM disk cache and will load models from HDD. " +
                "If you use a custom ComfyUI path, add the swarm_ram_cache block to your " +
                "extra_model_paths.yaml manually (see README).");
            return;
        }

        string wantedBase = CacheRoot.Replace('\\', '/');
        string yamlBlock  = BuildYamlBlock(wantedBase);

        string extraYaml = Path.Combine(comfyRoot, "extra_model_paths.yaml");
        try
        {
            string existing = File.Exists(extraYaml) ? File.ReadAllText(extraYaml) : "";

            if (!existing.Contains("swarm_ram_cache:"))
            {
                File.WriteAllText(extraYaml, yamlBlock + "\n" + existing);
                Logs.Info($"[HDDModelLoader] Prepended swarm_ram_cache to extra_model_paths.yaml → {wantedBase}");
                Logs.Info("[HDDModelLoader] *** Restart ComfyUI once (relaunch SwarmUI) for the new paths to take effect. ***");
            }
            else if (!existing.Contains($"base_path: {wantedBase}"))
            {
                string updated = ReplaceYamlBlock(existing, yamlBlock);
                File.WriteAllText(extraYaml, updated);
                Logs.Info($"[HDDModelLoader] Updated swarm_ram_cache in extra_model_paths.yaml → {wantedBase}");
                Logs.Info("[HDDModelLoader] *** Restart ComfyUI once (relaunch SwarmUI) for the updated paths to take effect. ***");
            }
            else
            {
                Logs.Debug("[HDDModelLoader] extra_model_paths.yaml already up to date.");
            }
        }
        catch (Exception ex)
        {
            Logs.Warning($"[HDDModelLoader] Could not update extra_model_paths.yaml: {ex.Message}");
        }

        string ramYaml = Path.Combine(comfyRoot, "swarm_ram_cache.yaml");
        try
        {
            if (!File.Exists(ramYaml) ||
                !File.ReadAllText(ramYaml).Contains($"base_path: {wantedBase}"))
            {
                File.WriteAllText(ramYaml,
                    "# Auto-generated by HDDModelLoader SwarmUI extension.\n" +
                    "# Safe to delete — it will be recreated on next launch.\n" +
                    yamlBlock);
                Logs.Debug($"[HDDModelLoader] Wrote swarm_ram_cache.yaml → {wantedBase}");
            }
        }
        catch (Exception ex)
        {
            Logs.Warning($"[HDDModelLoader] Could not write swarm_ram_cache.yaml: {ex.Message}");
        }
    }

    private static string BuildYamlBlock(string basePath) =>
        "swarm_ram_cache:\n" +
        $"  base_path: {basePath}\n" +
        "  checkpoints: checkpoints\n" +
        "  diffusion_models: diffusion_models\n" +
        "  unet: diffusion_models\n" +
        "  loras: loras\n" +
        "  vae: vae\n" +
        "  controlnet: controlnet\n" +
        "  clip: clip\n" +
        "  upscale_models: upscale_models\n" +
        "  embeddings: embeddings\n";

    private static string ReplaceYamlBlock(string yaml, string newBlock)
    {
        int start = yaml.IndexOf("swarm_ram_cache:", StringComparison.Ordinal);
        if (start < 0)
            return newBlock + "\n" + yaml;

        int search = yaml.IndexOf('\n', start);
        int end    = -1;
        while (search >= 0 && search < yaml.Length - 1)
        {
            search++;
            char c = yaml[search];
            if (c != ' ' && c != '\t' && c != '#' && c != '\n' && c != '\r')
            {
                end = search;
                break;
            }
            search = yaml.IndexOf('\n', search);
        }

        string rest   = end >= 0 ? yaml[end..] : "";
        string before = start > 0 ? yaml[..start].TrimEnd() + "\n\n" : "";
        return newBlock + "\n" + before + rest;
    }

    private static string FindComfyRoot(string basePath)
    {
        string[] candidates =
        [
            Path.Combine(basePath, "dlbackend", "comfy", "ComfyUI"),
            Path.Combine(basePath, "dlbackend", "ComfyUI"),
            Path.Combine(basePath, "dlbackend", "comfy"),
            Path.Combine(basePath, "ComfyUI"),
        ];

        foreach (string c in candidates)
            if (Directory.Exists(c) && File.Exists(Path.Combine(c, "main.py")))
                return c;

        foreach (string c in candidates)
            if (Directory.Exists(c))
                return c;

        return "";
    }

    // ── Copy with progress bar ─────────────────────────────────────────────────

    private static void CopyWithProgress(string src, string dest, long totalBytes)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(dest)!);

        int    bufSize   = ReadBufMiB * 1024 * 1024;
        byte[] buf       = new byte[bufSize];
        long   copied    = 0;
        long   prevBytes = 0;
        var    sw        = Stopwatch.StartNew();
        var    prevTime  = sw.Elapsed;

        using var reader = new FileStream(src,  FileMode.Open,   FileAccess.Read,  FileShare.Read,
                                          bufSize, FileOptions.SequentialScan);
        using var writer = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None,
                                          bufSize);
        int read;
        while ((read = reader.Read(buf, 0, buf.Length)) > 0)
        {
            writer.Write(buf, 0, read);
            copied += read;

            var    now      = sw.Elapsed;
            double chunkSec = (now - prevTime).TotalSeconds;
            double mbps     = chunkSec > 0.05
                ? (copied - prevBytes) / (1024.0 * 1024.0) / chunkSec
                : 0;
            prevBytes = copied;
            prevTime  = now;

            double pct    = totalBytes > 0 ? (double)copied / totalBytes : 0;
            int    filled = (int)(pct * BarWidth);
            string bar    = new string('\u2588', filled) + new string('-', BarWidth - filled);
            long   mibDone  = copied    / (1024 * 1024);
            long   mibTotal = totalBytes / (1024 * 1024);

            Console.Write(
                $"\r  Loading model from HDD: [{bar}] {pct * 100,3:F0}%" +
                $" | {mbps,5:F0} MB/s  ({mibDone}/{mibTotal} MiB)   ");
        }

        double avgMbps = sw.Elapsed.TotalSeconds > 0
            ? (totalBytes / (1024.0 * 1024.0)) / sw.Elapsed.TotalSeconds : 0;
        long mib = totalBytes / (1024 * 1024);
        Console.WriteLine(
            $"\r  Loading model from HDD: [{new string('\u2588', BarWidth)}] 100%" +
            $" | avg {avgMbps,5:F0} MB/s  ({mib}/{mib} MiB)   ");
    }
}
